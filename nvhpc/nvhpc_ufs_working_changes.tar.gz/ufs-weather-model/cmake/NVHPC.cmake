# Local NVHPC compiler settings for UFS.
# Based on cmake/GNU.cmake, translated for nvc/nvc++/nvfortran.

if(MOVING_NEST)
  message(FATAL_ERROR "Option MOVING_NEST not compatible with ${CMAKE_Fortran_COMPILER_ID}")
endif()

# GNU equivalents:
#   -ggdb                  -> -g
#   -fbacktrace            -> omit; NVHPC does not use this flag
#   -cpp                   -> -Mpreprocess
#   -fcray-pointer         -> -Mcray=pointer
#   -ffree-line-length-none -> -Mextend
#   -fno-range-check       -> omit initially
set(CMAKE_Fortran_FLAGS "${CMAKE_Fortran_FLAGS} -g -Mpreprocess -Mcray=pointer")

# In this UFS logic, NOT 32BIT means promote default real/double to 8 bytes.
# NVHPC equivalent is -r8.
if(NOT 32BIT)
  set(CMAKE_Fortran_FLAGS "${CMAKE_Fortran_FLAGS} -r8")
endif()

if(DEBUG)
  add_definitions(-DDEBUG)

  # Conservative NVHPC debug flags.
  set(CMAKE_Fortran_FLAGS_DEBUG "${CMAKE_Fortran_FLAGS_DEBUG} -O0 -g -Mbounds -Mchkptr")
  set(CMAKE_C_FLAGS_DEBUG "${CMAKE_C_FLAGS_DEBUG} -O0 -g")
  set(CMAKE_CXX_FLAGS_DEBUG "${CMAKE_CXX_FLAGS_DEBUG} -O0 -g")
else()
  set(CMAKE_Fortran_FLAGS_RELEASE "-O2")
  set(CMAKE_C_FLAGS_RELEASE "-O2")
  set(CMAKE_CXX_FLAGS_RELEASE "-O2")
endif()

if(WARN_AS_ERROR)
  # NVHPC supports -Werror in many cases, but leave it conservative.
  set(CMAKE_Fortran_FLAGS "${CMAKE_Fortran_FLAGS} -Werror")
endif()
