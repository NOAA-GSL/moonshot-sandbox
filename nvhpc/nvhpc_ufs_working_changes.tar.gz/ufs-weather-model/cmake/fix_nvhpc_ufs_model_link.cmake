if(NOT EXISTS "${LINK_TXT}")
  message(FATAL_ERROR "link.txt not found: ${LINK_TXT}")
endif()

file(READ "${LINK_TXT}" link_line)

# Final ufs_model link also needs the NVHPC OpenACC runtime.
if(NOT link_line MATCHES " -acc( |$)")
  string(REPLACE " -o ufs_model " " -acc -o ufs_model " link_line "${link_line}")
endif()

# Remove loose/early GPTL refs that occur before PIO is pulled from static archives.
string(REPLACE " ${GPTL}" "" link_line "${link_line}")
string(REPLACE " -lgptl " " " link_line "${link_line}")

# Remove an early PIO/GPTL group if one was inserted too soon.
string(REPLACE
  " -Wl,--start-group ${PIOF} ${PIOC} ${GPTL} -Wl,--end-group"
  ""
  link_line
  "${link_line}"
)

# Replace the PIO archive pair with the working grouped form.
# Do this only once; otherwise repeated relinks keep nesting start/end groups.
if(NOT link_line MATCHES "-Wl,--start-group[ ]+\\$\\{PIOF\\}[ ]+\\$\\{PIOC\\}[ ]+\\$\\{GPTL\\}[ ]+-Wl,--end-group")
  string(REPLACE
    "${PIOF} ${PIOC}"
    "-Wl,--start-group ${PIOF} ${PIOC} ${GPTL} -Wl,--end-group"
    link_line
    "${link_line}"
  )
endif()

# Collapse any duplicate group flags already accumulated in link.txt.
while(link_line MATCHES "-Wl,--start-group[ ]+-Wl,--start-group")
  string(REPLACE "-Wl,--start-group -Wl,--start-group" "-Wl,--start-group" link_line "${link_line}")
endwhile()
while(link_line MATCHES "-Wl,--end-group[ ]+-Wl,--end-group")
  string(REPLACE "-Wl,--end-group -Wl,--end-group" "-Wl,--end-group" link_line "${link_line}")
endwhile()

file(WRITE "${LINK_TXT}" "${link_line}")
