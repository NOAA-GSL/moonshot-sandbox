if(NOT EXISTS "${LINK_TXT}")
  message(FATAL_ERROR "link.txt not found: ${LINK_TXT}")
endif()

file(READ "${LINK_TXT}" link_line)

# Remove loose/early GPTL refs that appear before the MPAS static libs.
string(REPLACE " ${GPTL}" "" link_line "${link_line}")
string(REPLACE " -lgptl " " " link_line "${link_line}")

# Remove an early PIO/GPTL group if one was inserted too soon.
string(REPLACE
  " -Wl,--start-group ${PIOF} ${PIOC} ${GPTL} -Wl,--end-group"
  ""
  link_line
  "${link_line}"
)

# Replace the final PIO archive pair with the working grouped form.
string(REPLACE
  "${PIOF} ${PIOC}"
  "-Wl,--start-group ${PIOF} ${PIOC} ${GPTL} -Wl,--end-group"
  link_line
  "${link_line}"
)

file(WRITE "${LINK_TXT}" "${link_line}")
